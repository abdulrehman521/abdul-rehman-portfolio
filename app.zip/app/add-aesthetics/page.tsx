// "use client"

// import { useState, useEffect } from "react"
// import { Button } from "@/components/ui/button"
// import { Input } from "@/components/ui/input"
// import { Label } from "@/components/ui/label"
// import { supabase } from "@/lib/supabaseClient"
// import { X } from "lucide-react"
// import { useToast } from "@/hooks/use-toast"
// import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
// import { useRouter } from "next/navigation"
// import Link from "next/link"

// export default function AddAestheticsPage() {
//   const [files, setFiles] = useState<File[]>([])
//   const [category, setCategory] = useState("")
//   const [categories, setCategories] = useState<string[]>([])
//   const [images, setImages] = useState<any[]>([])
//   const [selectedCategory, setSelectedCategory] = useState<string>("All")
//   const { toast } = useToast()
//   const router = useRouter()

//   useEffect(() => {
//     fetchCategories()
//     fetchImages()
//   }, [])

//   const fetchCategories = async () => {
//     const { data, error } = await supabase.from("images").select("folder")
//     if (error) {
//       console.error(error)
//       return
//     }
//     const uniqueCategories = Array.from(new Set(data.map((item) => item.folder)))
//     setCategories(uniqueCategories)
//   }

//   const fetchImages = async () => {
//     const { data, error } = await supabase
//       .from("images")
//       .select("*")
//       .order("created_at", { ascending: false })
//     if (error) console.error(error)
//     else setImages(data || [])
//   }

//   const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
//     if (e.target.files) {
//       setFiles([...files, ...Array.from(e.target.files)])
//     }
//   }

//   const handleUpload = async () => {
//     if (!files.length || !category) {
//       toast({ title: "Error", description: "Please select files and category", variant: "destructive" })
//       return
//     }

//     for (const file of files) {
//       const formData = new FormData()
//       formData.append("file", file)
//       formData.append("upload_preset", "YOUR_CLOUDINARY_PRESET")

//       const cloudinaryRes = await fetch(
//         `https://api.cloudinary.com/v1_1/YOUR_CLOUD_NAME/image/upload`,
//         { method: "POST", body: formData }
//       )

//       const cloudinaryData = await cloudinaryRes.json()
//       if (cloudinaryData.secure_url) {
//         await supabase.from("images").insert({
//           url: cloudinaryData.secure_url,
//           folder: category,
//         })
//       }
//     }

//     toast({ title: "Success", description: "Images uploaded successfully" })
//     setFiles([])
//     setCategory("")
//     fetchImages()
//     fetchCategories()
//   }

//   const handleDelete = async (id: string) => {
//     await supabase.from("images").delete().eq("id", id)
//     toast({ title: "Deleted", description: "Image removed from database" })
//     fetchImages()
//     fetchCategories()
//   }

//   const filteredImages =
//     selectedCategory === "All"
//       ? images
//       : images.filter((img) => img.folder === selectedCategory)

//   return (
//     <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black text-white">
//       {/* Navbar */}
//       <nav className="bg-black/50 backdrop-blur-md border-b border-amber-500/20 px-6 py-4 flex items-center justify-between sticky top-0 z-50">
//         <h1 className="text-lg font-bold text-amber-500">Aesthetic Manager</h1>
//         <div className="space-x-4">
//           <Link href="/">
//             <Button variant="outline">Home</Button>
//           </Link>
//           <Button variant="outline" onClick={() => router.back()}>← Back</Button>
//         </div>
//       </nav>

//       <div className="p-8 grid grid-cols-1 md:grid-cols-2 gap-8">
//         {/* Upload Form */}
//         <Card className="bg-black/60 border-amber-500/20">
//           <CardHeader>
//             <CardTitle>Upload Aesthetic Images</CardTitle>
//           </CardHeader>
//           <CardContent>
//             <div className="space-y-4">
//               <Input type="file" multiple onChange={handleFileChange} className="bg-gray-800" />
//               <div>
//                 <Label>Category</Label>
//                 <select
//                   value={category}
//                   onChange={(e) => setCategory(e.target.value)}
//                   className="w-full bg-gray-800 border border-gray-700 rounded px-3 py-2"
//                 >
//                   <option value="">Select a category</option>
//                   {categories.map((cat) => (
//                     <option key={cat} value={cat}>
//                       {cat}
//                     </option>
//                   ))}
//                 </select>
//               </div>
//               <Button onClick={handleUpload} className="w-full bg-amber-500 hover:bg-amber-600">
//                 Upload
//               </Button>
//             </div>
//           </CardContent>
//         </Card>

//         {/* Image List */}
//         <Card className="bg-black/60 border-amber-500/20">
//           <CardHeader className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
//             <CardTitle>Existing Images</CardTitle>
//             <select
//               value={selectedCategory}
//               onChange={(e) => setSelectedCategory(e.target.value)}
//               className="bg-gray-800 border border-gray-700 rounded px-3 py-2"
//             >
//               <option value="All">All Categories</option>
//               {categories.map((cat) => (
//                 <option key={cat} value={cat}>
//                   {cat}
//                 </option>
//               ))}
//             </select>
//           </CardHeader>
//           <CardContent>
//             <div className="grid grid-cols-2 gap-4">
//               {filteredImages.map((img) => (
//                 <div key={img.id} className="relative group">
//                   <img
//                     src={img.url}
//                     alt=""
//                     className="w-full h-32 object-cover rounded-lg transition-transform duration-300 group-hover:scale-105"
//                   />
//                   <div className="absolute top-1 left-1 bg-black/60 px-2 py-1 text-xs rounded">
//                     {img.folder}
//                   </div>
//                   <button
//                     onClick={() => handleDelete(img.id)}
//                     className="absolute top-1 right-1 bg-red-500 hover:bg-red-600 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition"
//                   >
//                     <X className="w-4 h-4" />
//                   </button>
//                 </div>
//               ))}
//             </div>
//           </CardContent>
//         </Card>
//       </div>
//     </div>
//   )
// }

"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { supabase } from "@/lib/supabaseClient"
import { X } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useRouter } from "next/navigation"
import Link from "next/link"

export default function AddAestheticsPage() {
  const [files, setFiles] = useState<File[]>([])
  const [category, setCategory] = useState("")
  const [images, setImages] = useState<any[]>([])
  const [selectedCategory, setSelectedCategory] = useState<string>("All")
  const { toast } = useToast()
  const router = useRouter()

  // Hardcoded categories
  const categories = ["Aesthetics", "Corporate", "Fashion Product", "Sports", "Wedding"]

  useEffect(() => {
    fetchImages()
  }, [])

  const fetchImages = async () => {
    const { data, error } = await supabase
      .from("images")
      .select("*")
      .order("created_at", { ascending: false })
    if (error) console.error(error)
    else setImages(data || [])
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles([...files, ...Array.from(e.target.files)])
    }
  }

  const handleUpload = async () => {
    if (!files.length || !category) {
      toast({ title: "Error", description: "Please select files and category", variant: "destructive" })
      return
    }

    for (const file of files) {
      const formData = new FormData()
      formData.append("file", file)
      formData.append("upload_preset", "ml_default") // Your unsigned preset in Cloudinary

      const cloudinaryRes = await fetch(
        `https://api.cloudinary.com/v1_1/dk4pwokx3/image/upload`,
        { method: "POST", body: formData }
      )

      const cloudinaryData = await cloudinaryRes.json()
      if (cloudinaryData.secure_url) {
        await supabase.from("images").insert({
          url: cloudinaryData.secure_url,
          folder: category,
        })
      }
    }

    toast({ title: "Success", description: "Images uploaded successfully" })
    setFiles([])
    setCategory("")
    fetchImages()
  }

  const handleDelete = async (id: string) => {
    await supabase.from("images").delete().eq("id", id)
    toast({ title: "Deleted", description: "Image removed from database" })
    fetchImages()
  }

  const filteredImages =
    selectedCategory === "All"
      ? images
      : images.filter((img) => img.folder === selectedCategory)

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black text-white">
      {/* Navbar */}
   
      <nav className="bg-black/50 backdrop-blur-md border-b border-amber-500/20 px-6 py-4 flex items-center justify-between sticky top-0 z-50">
        <h1 className="text-lg font-bold text-amber-500">Aesthetic Manager</h1>
        <div className="space-x-4">
          <Link href="/">
            <Button variant="outline">Home</Button>
          </Link>
          <Button variant="outline" onClick={() => router.back()}>← Back</Button>
        </div>
      </nav>

      <div className="p-8 grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Upload Form */}
        <Card className="bg-black/60 border-amber-500/20">
          <CardHeader>
            <CardTitle>Upload Images</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Input type="file" multiple onChange={handleFileChange} className="bg-gray-800" />
              <div>
                <Label>Category</Label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full bg-gray-800 border border-gray-700 rounded px-3 py-2"
                >
                  <option value="">Select a category</option>
                  {categories.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>
              <Button onClick={handleUpload} className="w-full bg-amber-500 hover:bg-amber-600">
                Upload
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Image List */}
        <Card className="bg-black/60 border-amber-500/20">
          <CardHeader className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <CardTitle>Existing Images</CardTitle>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="bg-gray-800 border border-gray-700 rounded px-3 py-2"
            >
              <option value="All">All Categories</option>
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              {filteredImages.map((img) => (
                <div key={img.id} className="relative group">
                  <img
                    src={img.url}
                    alt=""
                    className="w-full h-32 object-cover rounded-lg transition-transform duration-300 group-hover:scale-105"
                  />
                  <div className="absolute top-1 left-1 bg-black/60 px-2 py-1 text-xs rounded">
                    {img.folder}
                  </div>
                  <button
                    onClick={() => handleDelete(img.id)}
                    className="absolute top-1 right-1 bg-red-500 hover:bg-red-600 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
